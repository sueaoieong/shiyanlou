#-*- coding:utf-8 -*-

import scrapy

class getgithub(scrapy.Spider):
	name='shiyanlou-courses'

	@property
	def start_urls(self):
		urls=['https://github.com/shiyanlou?tab=repositories','https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoxOTo1N1rOBZKWMA%3D%3D&tab=repositories','https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNS0wMS0yNVQwMzozMTowN1rOAca7MQ%3D%3D&tab=repositories','https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNC0xMS0yMFQwNTowMzo1MlrOAY5Lyw%3D%3D&tab=repositories']
		return urls

	def parse(self,response):
		for repo in response.css('li.col-12'):
			yield {
				'name':repo.css('li.col-12 a::text').re_first("\n      (.+)"),
				'update_time':repo.css('li.col-12 relative-time::attr(datetime)').extract_first()
			}