#!/usr/bin/env python3

import sys, csv, getopt, configparser ,datetime
from multiprocessing import Process,Queue

class Config():
	def __init__(self,configfile):
		self.con=configparser.ConfigParser()
		self.file=configfile
		

	def get_config(self):
		
		self.con.read(self.file)
		

class UserData():
	def __init__(self,userdatafile,configfile,city,outputfile):
		#self.userdata={}
		self.file=userdatafile
		self.configfile=Config(configfile)
		self.configfile.get_config()
		self.city=city.upper()
		self.outputfile=outputfile
		#self.get_data()
	
		#print(self.configfile._config)


	def get_data(self,q):
		userdata={}
		with open(self.file,'r') as file:
			data=file.readlines()
		#print(data)
		for x in data:
			key,value=x.split(',')
			#self.userdata[key]=int(value.strip())
			userdata[key]=int(value.strip())
		
		q.put(userdata)
		#print(userdata)
		#print(self.userdata)

	def calculator(self,q1,q2):
		try:
			data=q1.get()
		except q1.Empty():
			print("queue is empty.")
		newdata=[]
		for x in data:
			salary=data[x]
			#five insurance

			if salary<float(self.configfile.con[self.city]['JiShuL']):
				salary1=float(self.configfile.con[self.city]['JiShuL'])
			elif salary>float(self.configfile.con[self.city]['JiShuH']):
				salary1=float(self.configfile.con[self.city]['JiShuH'])
			else:
				salary1=salary
			insurance=salary1*(float(self.configfile.con[self.city]['YangLao'])+float(self.configfile.con[self.city]['YiLiao'])+float(self.configfile.con[self.city]['ShiYe'])+float(self.configfile.con[self.city]['GongShang'])+float(self.configfile.con[self.city]['GongJiJin']))
			#print(insurance)
			#tax
			if salary-insurance>3500:
				temp=salary-insurance-3500
				if temp<=1500:
					tax=temp*0.03
				elif 1500<temp<=4500:
					tax=temp*0.1-105
				elif 4500<temp<=9000:
					tax=temp*0.2-555
				elif 9000<temp<=35000:
					tax=temp*0.25-1005
				elif 35000<temp<=55000:
					tax=temp*0.3-2755
				elif 55000<temp<=80000:
					tax=temp*0.35-5505
				else:
					tax=temp*0.45-13505
			else:
				tax=0
			fin_salary=salary-insurance-tax
#result=[x,format(self.userdata[x],'.2f'),format(insurance,'.2f'),format(tax,'.2f'),format(fin_salary,'.2f')]
			
			person_data=[x,format(data[x],'.2f'),format(insurance,'.2f'),format(tax,'.2f'),format(fin_salary,'.2f'),datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S')]
			newdata.append(person_data)
		q2.put(newdata)
		
			#return insurance,tax,fin_salary

	def dumptofile(self,q):
		try:
			newdata=q.get()
		except q.Empty():

			print("queue is empty.")
		#print(outputfile)
		
		with open(self.outputfile,'w') as file:
			#print('success')
			for data in newdata:
				
					
				#insurance,tax,fin_salary=self.calculator(self.userdata[x])
				#result=[x,format(self.userdata[x],'.2f'),format(insurance,'.2f'),format(tax,'.2f'),format(fin_salary,'.2f')]
				#print(data)
				#print(type(result[1]))
				writer=csv.writer(file)
				writer.writerow(data)



if __name__=="__main__":
	args=sys.argv[1:]
	#print(args)
	param,args=getopt.getopt(args,'C:c:d:o:')
	#print(param)
	for p,p1 in param:
		if p=='-C':
			city=p1
		elif p=='-c':
			configfile=p1
		elif p=='-d':
			userdatafile=p1
		elif p=='-o':
			outputfile=p1
	test=UserData(userdatafile,configfile,city,outputfile)
	queue1=Queue()
	queue2=Queue()
	p1=Process(target=test.get_data,args=(queue1,))
	p1.start()
	#print('p1 finish')
	#self.get_data()
	p2=Process(target=test.calculator,args=(queue1,queue2))
	p2.start()
	#print('p2 finish')		
	
	p3=Process(target=test.dumptofile,args=(queue2,))
	p3.start()
	#print('p3 finish')
	#print(self.configfile._config)
	#test.dumptofile(outputfile)


