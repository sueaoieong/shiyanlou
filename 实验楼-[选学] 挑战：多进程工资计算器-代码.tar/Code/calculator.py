#!/usr/bin/env python3

import sys, csv
from multiprocessing import Process,Queue

class Config():
	def __init__(self,configfile):
		self._config={}
		self.file=configfile

	def get_config(self):
		with open(self.file,'r') as file:
			data=file.readlines()
		for x in data:
			key,value=x.split('=')
			self._config[key.strip()]=float(value.strip())
		#print(self._config)

class UserData():
	def __init__(self,userdatafile,configfile,outputfile):
		#self.userdata={}
		self.file=userdatafile
		self.configfile=Config(configfile)
		self.configfile.get_config()
		self.outputfile=outputfile
		#self.get_data()
	
		#print(self.configfile._config)


	def get_data(self,q):
		userdata={}
		with open(self.file,'r') as file:
			data=file.readlines()
		#print(data)
		for x in data:
			key,value=x.split(',')
			#self.userdata[key]=int(value.strip())
			userdata[key]=int(value.strip())
		
		q.put(userdata)
		#print(userdata)
		#print(self.userdata)

	def calculator(self,q1,q2):
		try:
			data=q1.get()
		except q1.Empty():
			print("queue is empty.")
		newdata=[]
		for x in data:
			salary=data[x]
			#five insurance

			if salary<self.configfile._config['JiShuL']:
				salary1=self.configfile._config['JiShuL']
			elif salary>self.configfile._config['JiShuH']:
				salary1=self.configfile._config['JiShuH']
			else:
				salary1=salary
			insurance=salary1*(self.configfile._config['YangLao']+self.configfile._config['YiLiao']+self.configfile._config['ShiYe']+self.configfile._config['GongShang']+self.configfile._config['GongJiJin'])
			#print(insurance)
			#tax
			if salary-insurance>3500:
				temp=salary-insurance-3500
				if temp<=1500:
					tax=temp*0.03
				elif 1500<temp<=4500:
					tax=temp*0.1-105
				elif 4500<temp<=9000:
					tax=temp*0.2-555
				elif 9000<temp<=35000:
					tax=temp*0.25-1005
				elif 35000<temp<=55000:
					tax=temp*0.3-2755
				elif 55000<temp<=80000:
					tax=temp*0.35-5505
				else:
					tax=temp*0.45-13505
			else:
				tax=0
			fin_salary=salary-insurance-tax
#result=[x,format(self.userdata[x],'.2f'),format(insurance,'.2f'),format(tax,'.2f'),format(fin_salary,'.2f')]
			person_data=[x,format(data[x],'.2f'),format(insurance,'.2f'),format(tax,'.2f'),format(fin_salary,'.2f')]
			newdata.append(person_data)
		q2.put(newdata)
		
			#return insurance,tax,fin_salary

	def dumptofile(self,q):
		try:
			newdata=q.get()
		except q.Empty():

			print("queue is empty.")
		#print(outputfile)
		with open(self.outputfile,'w') as file:
			#print('success')
			for data in newdata:
				
					
				#insurance,tax,fin_salary=self.calculator(self.userdata[x])
				#result=[x,format(self.userdata[x],'.2f'),format(insurance,'.2f'),format(tax,'.2f'),format(fin_salary,'.2f')]
				#print(data)
				#print(type(result[1]))
				writer=csv.writer(file)
				writer.writerow(data)



if __name__=="__main__":
	args=sys.argv[1:]
	#print(args)
	try:
		index1=args.index('-c')
		index2=args.index('-d')
		index3=args.index('-o')
		configfile=args[index1+1]
		userdatafile=args[index2+1]
		outputfile=args[index3+1]
	except ValueError as e:
		print(e)
	test=UserData(userdatafile,configfile,outputfile)
	queue1=Queue()
	queue2=Queue()
	p1=Process(target=test.get_data,args=(queue1,))
	p1.start()
	#print('p1 finish')
	#self.get_data()
	p2=Process(target=test.calculator,args=(queue1,queue2))
	p2.start()
	#print('p2 finish')		
	
	p3=Process(target=test.dumptofile,args=(queue2,))
	p3.start()
	#print('p3 finish')
	#print(self.configfile._config)
	#test.dumptofile(outputfile)

