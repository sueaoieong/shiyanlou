# -*- coding: utf-8 -*-
import scrapy
from shiyanlougithub.items import githubItem

class GetgithubSpider(scrapy.Spider):
	name = 'getgithub'
	
	def start_urls(self):
		urls=['https://github.com/shiyanlou?tab=repositories','https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK0MjAxNy0wNi0wNlQyMjoxOTo1N1rOBZKWMA%3D%3D&tab=repositories','https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNS0wMS0yNVQxMTozMTowNyswODowMM4Bxrsx&tab=repositories','https://github.com/shiyanlou?after=Y3Vyc29yOnYyOpK5MjAxNC0xMS0yMFQxMzowMzo1MiswODowMM4BjkvL&tab=repositories']
		return urls

	def parse(self, response):
		for tmp in response.css('li.col-12'):
			item=githubItem({
			'name':response.css('div.mb-1 a::text').extract_first(),
			'update-time':response.css('relative-time::attr(datetime)').extract_first()
			})

			yield item
