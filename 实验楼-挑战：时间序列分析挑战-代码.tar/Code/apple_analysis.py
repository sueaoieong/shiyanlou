# -*- coding:utf-8 -*-

import pandas as pd


def quarter_volume():
	data=pd.read_csv('apple.csv',header=0)
	data['Date']=pd.to_datetime(data['Date'])
	data=data.set_index('Date')
	data_sum=data.resample('Q').sum()
	data_sort=data_sum.sort_values(by='Volume',ascending=False)
	second_volume=data_sort.iloc[1]['Volume']

	return second_volume


if __name__=='__main__':
	print(quarter_volume())

