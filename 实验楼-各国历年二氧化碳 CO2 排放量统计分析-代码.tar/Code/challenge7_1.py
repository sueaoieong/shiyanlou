# -*- coding: utf-8 -*-

import pandas as pd
def co2():

	df_climate=pd.read_excel("ClimateChange.xlsx",sheetname='Data')
	df_Country=pd.read_excel("ClimateChange.xlsx",sheetname='Country')
	Series_code='EN.ATM.CO2E.KT'
	nonOECD
	nonOECD
	Upper_middle
	Lower_middle
	Low