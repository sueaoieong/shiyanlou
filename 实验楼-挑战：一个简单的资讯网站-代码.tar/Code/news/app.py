#!/usr/bin/env python3

from flask import Flask,render_template
import json,os

app=Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD']=True

@app.route('/')
def index():
    path='/home/shiyanlou/files/'
    files=os.listdir(path)
    title=[]
    for x in files:
        realpath=path+x
        with open(realpath,'r') as f:
              data=json.load(f)
              title.append(data['title'])

    return render_template('index.html',file=title)

@app.route('/files/<filename>')
def file(filename):
    f='/home/shiyanlou/files/'+filename+'.json'
    if filename=='helloshiyanlou'or filename=='helloworld':
        with open(f,'r') as file:
            data=json.load(file)
        return render_template('file.html',data=data)
    else:
        return render_template('404.html')
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html')

    
