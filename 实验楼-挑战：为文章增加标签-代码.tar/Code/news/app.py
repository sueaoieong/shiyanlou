#!/usr/bin/env python3

from flask import Flask,render_template
from flask_sqlalchemy import SQLAlchemy
from pymongo import MongoClient
import json,os

app=Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD']=True
app.config['SQLALCHEMY_DATABASE_URI']='mysql://root@localhost/mydb'
db=SQLAlchemy(app)
client=MongoClient('127.0.0.1',27017)
mon_db=client.mydb

class Category(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(80))
    def __init__(self,name):
        self.name=name
    def __repr__(self):
        return '<Category %r>' % self.name


class File(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    title=db.Column(db.String(80))
    created_time=db.Column(db.DateTime)
    category_id=db.Column(db.Integer,db.ForeignKey('category.id'))
    content=db.Column(db.Text)
    category=db.relationship('Category',backref=db.backref('file',lazy='dynamic'))

    def __init__(self,title,created_time,category,content):
        self.title=title
        self.created_time=created_time
        self.category=category
        self.content=content

    def __repr__(self):
        return '<File %r>' % self.title
    
    def add_tag(self,tag_name):
        id=File.query.filter_by(title=self.title).first()
        print(id)
        tag={'file_id':id,'tags':tag_name}
        checker=mydb.file_tag.find({'tags':tag_name})
        if checker==None:
            mydb.file_tag.insert_one(tag)
        else:
            print("this tag is exist!")



    def remove_tag(self,tag_name):
        tag={'tags':tag_name}
        target=mydb.file_tag.find(tag)
        if target:
            mydb.file_tag.delete_one(tag)

    @property
    def tags(self):
        self.tags=[]
        for t in db.query.filter_by(title=self.title).all():
            self.tags.append(t['tags'])
        return self.tags


    
@app.route('/')
def index():
    
    file_db=File.query.first()
    print (file_db.title)
    return render_template('index.html',file=File.query.all())

@app.route('/files/<file_id>')
def file(file_id):
    if File.query.filter_by(id=file_id).first():
        return render_template('file.html',file=File.query.filter_by(id=file_id).first())
    else:
        return render_template('404.html')
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html')

if __name__=='__main__':
    db.create_all()

